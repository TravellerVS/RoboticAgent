#ifndef RMI_COMPASS_H
#define RMI_COMPASS_H


int getCompassValue(void);
void initCompass(void);


#endif

